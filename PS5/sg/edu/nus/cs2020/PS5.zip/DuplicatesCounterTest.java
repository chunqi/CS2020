package sg.edu.nus.cs2020;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.junit.Test;

public class DuplicatesCounterTest
{
	@Test
	public void hashTest()
	{
		int[] input = {65};
		String output = DuplicatesCounter.getHashLong(input);
		
		System.out.println(output);
		
		//MD5 hash of 'A' in ASCII
		assertEquals(0, output.compareTo("�bp��Y5�.��)"));
	}
	
	@Test
	public void duplicatesCountPSExampleTest()
	{
		String filename = "sg/edu/nus/cs2020/PSexample.txt";
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		
		try
		{
			fileReader = new FileReader(filename);
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Error: File <" + filename + "> not found.");
		}
		
		bufferedReader = new BufferedReader(fileReader);	
		DuplicatesCounter counter = new DuplicatesCounter(bufferedReader);
		
		int duplicatesCount = counter.getDuplicatesCount();
		System.out.println(duplicatesCount);
		assertEquals(6, duplicatesCount);
	}
	
	@Test
	public void duplicatesCountNoDuplicatesTest()
	{
		String filename = "sg/edu/nus/cs2020/noDuplicates.txt";
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		
		try
		{
			fileReader = new FileReader(filename);
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Error: File <" + filename + "> not found.");
		}
		
		bufferedReader = new BufferedReader(fileReader);
		DuplicatesCounter counter = new DuplicatesCounter(bufferedReader);
		
		int duplicatesCount = counter.getDuplicatesCount();
		System.out.println(duplicatesCount);
		assertEquals(0, duplicatesCount);
	}
	
	@Test
	public void duplicatesCountAllDuplicatesTest()
	{
		String filename = "sg/edu/nus/cs2020/allDuplicates.txt";
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		
		try
		{
			fileReader = new FileReader(filename);
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Error: File <" + filename + "> not found.");
		}
		
		bufferedReader = new BufferedReader(fileReader);
		DuplicatesCounter counter = new DuplicatesCounter(bufferedReader);
		
		int duplicatesCount = counter.getDuplicatesCount();
		System.out.println(duplicatesCount);
		assertEquals(45, duplicatesCount);
	}
	
	@Test
	public void duplicatesCountComplex3AllDuplicatesTest()
	{
		String filename = "sg/edu/nus/cs2020/complex3AllDuplicates.txt";
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		
		try
		{
			fileReader = new FileReader(filename);
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Error: File <" + filename + "> not found.");
		}
		
		bufferedReader = new BufferedReader(fileReader);
		DuplicatesCounter counter = new DuplicatesCounter(bufferedReader);
		
		int duplicatesCount = counter.getDuplicatesCount();
		System.out.println(duplicatesCount);
		assertEquals(45, duplicatesCount);
	}
}
