package sg.edu.nus.cs2020;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;

public class ZhuPS5
{
	public static void main(String[] args)
	{
		//Initialize and start stopwatch
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		
		String filename;
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		
		//For debugging with sample input
		if(args.length > 0) filename = args[0];
		else filename = "sg/edu/nus/cs2020/4.in.txt";
		
		//Instantiate FileReader and BufferedReader
		try
		{
			fileReader = new FileReader(filename);
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Error: File <" + filename + "> not found.");
		}
		
		bufferedReader = new BufferedReader(fileReader);
		
		//Instantiate DuplicatesCounter and pass it the BufferedReader
		DuplicatesCounter counter = new DuplicatesCounter(bufferedReader);
		
		//Print the duplicates count
		System.out.println(counter.getDuplicatesCount());
		
		//Stop the stopwatch and output time elapsed
		stopWatch.stop();
		BigDecimal timeElapsed = new BigDecimal(stopWatch.getTime());
		//System.out.println("Time taken: " + timeElapsed.toPlainString() + "s");
	}
}
